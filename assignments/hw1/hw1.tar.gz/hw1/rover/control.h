
/*******************************************************
 *
 *  Rover Header File for EECE 494
 *
 *  University of British Columbia, ECE
 *	Steve Wilton & Sathish Gopalakrishnan
 *
 *  This file is the header file for the controller routines 
 *
 ******************************************************/

/* Prototypes for the functions in control.c that routines
   in other files might want to call.  Only routines listed
   here will be visible outside control.c */

void your_code();


